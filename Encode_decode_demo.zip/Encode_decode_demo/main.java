import java.io.File;

public class main
{
	public static void main(String args[]) throws Exception
	{
		encode e_obj=new encode();
		decode d_obj=new decode();
		Encryption emp=e_obj.encodeTheInput("a.txt","manju","aFrsdhjewFtdWdtD");
		//System.out.println(emp.getStringLength());
		String hash=d_obj.decodeTheInput("unicodewatermark.notepad","manju","aFrsdhjewFtdWdtD",emp.getStringLength());
	}
}
