import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



class decode
{


	public static String decodeTheInput(String filepath, String watermark, String key, int stringLength)
            throws Exception {
        // TODO:

        File in = new File(filepath);
        FileInputStream fileInputStream = new FileInputStream(in);
        // System.out.println(Charset.availableCharsets());
        BufferedReader bin = new BufferedReader(new InputStreamReader(fileInputStream, "UTF-8"));
        Map<String, String> map = new HashMap<>();
        map.put("U+200b", "00");
        map.put("U+200c", "01");
        map.put("U+200d", "10");
        map.put("U+180e", "11");
        
	String binaryString = "";
        

        char[] b = new char[(int)in.length()];
        bin.read(b);
        bin.close();
        fileInputStream.close();
        String readData = new String(b);
        char[] charArr = readData.toCharArray();

	//char[] charArray=readData.toCharArray();

	String str="";

	
	System.out.println("size of charArray :"+charArr.length);

	List<String> l=new ArrayList<String>();
	int count=0;
	int temp=0;
	String output="";
	for(int i=0;i<charArr.length;i++)
	{
		if(map.get("U+" + Integer.toHexString(charArr[i] | 0x10000).substring(1))=="00")
		{
			count++;
			//System.out.println("count is:"+count+"\ti is"+i);
		}
		if(count==8)
		{
			count=0;
			temp++;
			binaryString="";
			i++;
			for(int j=0;j<352;j++,i++)
			{
	    			if (map.containsKey("U+" + Integer.toHexString(charArr[i] | 0x10000).substring(1))) {
                                        binaryString = binaryString + map.get("U+" + Integer.toHexString(charArr[i] | 0x10000).substring(1));
                                }
			}
			System.out.println("binaryWatermark : "+binaryString+"\n");
			StringBuilder sb = new StringBuilder();
		        Arrays.stream(binaryString.split("(?<=\\G.{8})")).forEach(s ->sb.append((char) Integer.parseInt(s, 2)));
        		output = sb.toString();
        		System.out.println("EmbeddingWatermark : SHA-256 :-" + output.toString()+"\n");			
		
			l.add(output);        		
		}


	}

	System.out.println("l is :"+l);
	System.out.println("\n"+temp+"\t times");

        //System.out.println("binaryWatermark.." + binaryString);
        //System.out.println("EmbeddingWatermark : SHA-256 :-" + output.toString());
        return output.toString();
	
	}


}
