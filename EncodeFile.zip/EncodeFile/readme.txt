

URL to upload file to encode:

http://localhost:8080/encodefile/
