package com.fortytwo.servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.fortytwo.service.EncodeFile;

@WebServlet("/upload")
public class FileUpload extends HttpServlet 
{
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		EncodeFile ef=new EncodeFile();
		try
		{
			ServletFileUpload sf=new ServletFileUpload(new DiskFileItemFactory());
			List<FileItem> files=sf.parseRequest(request);
		
			for(FileItem fileitem:files)
			{
				File file=new File("/home/u_can/eclipse_training/encodefile/" + fileitem.getName());
				fileitem.write(file);
				System.out.println("Encoding File: " + file.getName());
				File encryptfile=ef.encodeTheInput(file, "chirag", "dAtAbAsE98765432");
				System.out.println(encryptfile);
				request.getRequestDispatcher("download.jsp").forward(request,response);
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
		
		
		
	}

}
