package com.fortytwo.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import com.fortytwo.model.Encryption;



public class EncodeFile {
	
	public File encodeTheInput(File filename,String watermark,String key) throws Exception {
		
			
		 	Encryption ecncryptData = new Encryption();
	        SecretKeySpec aesKey = new SecretKeySpec(key.getBytes(), "AES");
	        Cipher cipher = Cipher.getInstance("AES");
	        System.out.println("watermark:   " + watermark + ",   Kye:   " + key);

	        // encryptedWatermark for AES
	        cipher.init(Cipher.ENCRYPT_MODE, aesKey);
	        byte[] encrypted = cipher.doFinal(watermark.getBytes());
	        System.out.println("EncryptedWatermark: AES :- " + new String(encrypted));

	        // embeddingWatermark for SHA-256
	        MessageDigest digest = MessageDigest.getInstance("SHA-256");
	        byte[] hash = digest.digest(encrypted);
	        String encoded = Base64.getEncoder().encodeToString(hash);
	        System.out.println("EmbeddingWatermark : SHA-256 :- " + encoded);
	        ecncryptData.setHashKey(encoded);

	        // BigInteger one =new BigInteger(hash);
	        BigInteger one = new BigInteger(encoded.getBytes());
	        String str = one.toString(2);
	        System.out.println("binaryWatermark :- " + str);
	        System.out.println("binaryWatermarkLength..." + str.length());
	        ecncryptData.setStringLength(str.length());
	        // unicodeWatermark
	        List<String> list = new ArrayList<String>();
	        String unicodeWatermark = "";
	        if (str.length() != 0) {
	            for (int i = 0; i < str.length(); i++) {
	                unicodeWatermark = null;
	                if ((i % 2) != 0) {

	                    if (("" + str.charAt(i - 1) + str.charAt(i)).equals("00")) {
	                        unicodeWatermark = "\u200B";
	                    }
	                    else if (("" + str.charAt(i - 1) + str.charAt(i)).equals("01")) {
	                        unicodeWatermark = "\u200C";
	                    }
	                    else if (("" + str.charAt(i - 1) + str.charAt(i)).equals("10")) {
	                        unicodeWatermark = "\u200D";
	                    }
	                    else if (("" + str.charAt(i - 1) + str.charAt(i)).equals("11")) {
	                        unicodeWatermark = "\u180E";
	                    }
	                }
	                if (unicodeWatermark != null) {
	                    list.add(unicodeWatermark);
	                }
	            } // for
	        } // System.out.println(list);

	        // read plain text file
	        String listData = "";        
	        BufferedReader br = new BufferedReader(new FileReader(filename));
	        File file1 = new File("/home/u_can/eclipse_training/encodefile/unicodewatermark.notepad");
	        if (!file1.exists()) {
				file1.createNewFile();
				System.out.println("File created: " + file1.getName());
			} else {
				System.out.println("File already exists.");
			}
	        FileOutputStream fileOutputStream = new FileOutputStream(file1);
	        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
	        // write text file with unicode watermark
	        String st;
	        int k = 0;
	        int temp = 0;
	        System.out.println("unicode watermark length..:-" + list.size());
	        
	        while ((st = br.readLine()) != null) {
	            char[] ch = st.toCharArray();
	            for (int i = 0; i < ch.length; i++) {
	                if (list.size() == k) {
	                    temp = 1;
	                    k = 0;
	                }
	                listData += ch[i] + "" + list.get(k);
	                k++;
	            }
	            if (temp == 0 && listData.length() < 350) {
	                for (int j = listData.length() / 2; j < ch.length + 175; j++) {
	                    listData += list.get(j);
	                    if (j == 174) {
	                        break;
	                    }
	                }
	            }
	            System.out.println(listData);
	        } // while
	        
	        outputStreamWriter.write(listData);
	        outputStreamWriter.close();
	        fileOutputStream.close();
	        return file1;
	}
}
