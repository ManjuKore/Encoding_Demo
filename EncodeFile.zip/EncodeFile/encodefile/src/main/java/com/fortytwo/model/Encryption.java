package com.fortytwo.model;

public class Encryption {


	private int stringLength;
	private String hashKey;
	
	public int getStringLength() {
		return stringLength;
	}
	public void setStringLength(int stringLength) {
		this.stringLength = stringLength;
	}
	public String getHashKey() {
		return hashKey;
	}
	public void setHashKey(String hashKey) {
		this.hashKey = hashKey;
	}

	
}
